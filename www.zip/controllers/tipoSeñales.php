y(
"SR"=>"01:Pare|02:Ceda el paso|03:Siga de frente|04:No pase|05:Giro a la izq. solamente|06: Prohibido girar a la izq.|07:Giro a la derecha solamente|08:Prohibido girar a la derecha|09:Giro en U solamente|10:Prohibido girar en U|11:Doble Via|12:Tres carriles uno en contraflujo|13:Tres carriles dos en contraflujo|14:Prohibido el cambio de calzada izq. y der.|14A:Prohibido el cambio de calzada der. e izq.|16:Circulacion Prohibida de vehiculos automotores|17:vehiculos pesados a la der.|18:Circulacion Prohibida de vehiculos de carga|19:Peatones a la izq.|20:Circulacion previa de Peatones|21:Circulacion Prohibida de cabalgaduras|22:Circulacion Prohibidas de bicicletas|23:Circulacion Prohibidas de motocicletas|24: Circulacion Prohibida de maquinaria agricola|25:Circulacion Prohibida de vehiculos de traccion animal|26:Prohibido adelantar|28:Prohibido parquear|28A:No parquear y detenerse|29: Prohibido pitar|30: Velocidad max. permitida|30A: Velocidad min. permitida|30B:Velocidad max. permitida salida|31: Peso max. tota permitido|32:Altura max. permitida|33:Ancho max. permitido|34:Zona de estacionamiento de taxi|35: Circulacion con luces bajas|36: Reten|38: Sentido unico de Circulacion|39:Sentido de Circulacion Doble|40: Paradero|41:Prohibido dejar o recoger pasajeros|42:Zona de cargue y descargue|43: Prohibido cargue y descargue|44: Conservar espaciamiento|45: Indicacion de separador de transito a la izq.|46:Indicacion de separadorde transito a la der.|47: No bloquear cruce|48: Fin prohibicion de adelantamiento|49: Preferencia al sentido contrario|50: Prohibido girar a la der. con luz roja|51: Circulacion prohibida de carros de mano|52: Circulacion prohibida de buses|53:Circulacion prohibida de motocarros|54:Circulacion prohibida de cuatrimotos",
"SP"=>"01:Curva cerrada a la izq.|02:Curva cerrada a la der.|03:Curva pronunciada a la izq.|04:Curva pronunciada a la der.|05:Curva y contracurva cerrada primera a la izq.|06:Curva y contracurva cerrada primera a la der.|07:Zona de curvas sucesivas la primera a la izq.|08:Zona de curvas sucesivas la primera a la der.|09:Curva y contracurva pronunciada primera a la izq.|10:Curva y contracurva pronunciada primera a la der.",
"SI"=>"01:Ruta nacional|01A:Ruta departamental|02:Ruta panamericana|03:Ruta marginal de selva
|07:Sitio de parqueo|07A:Zona especial de parqueo|08:Paradero de buses|09:Estacionamiento de taxis|10:Transbordador",
"ST"=>"01:Zona de camping|02:Playa|03:Museo|04:Muella|05:Zoologico|06:Punto de informacion turistica|07:Artesanias|08:Bienes arqueologicos|09:Lago|10:Polideportivo|11:Mirador",

"Tablero"=>"Bueno|Regular|Malo",
"Pedestal"=>"Bueno|Regular|Malo",
"Anclaje"=>"Bueno|Regular|Malo",
"Vista"=>"No Visible|Poco Visible|Visible",
"Accion"=>"RETIRAR|REUBICAR|REMPLAZAR|MANTENIMIENTO|INVENTARIO"
);

sr=[{
01:Pare|02:Ceda el paso|03:Siga de frente|04:No pase|05:Giro a la izq. solamente|06: Prohibido girar a la izq.|07:Giro a la derecha solamente|08:Prohibido girar a la derecha|09:Giro en U solamente
}]